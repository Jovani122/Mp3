# MP3 Player — projet Android

Prototype Android natif Kotlin : demande d'autorisation audio, lecture de la bibliothèque locale via MediaStore et lecture via AndroidX Media3.

## Compiler l'APK

Prérequis : Android Studio (ou Android SDK + Gradle), JDK 17 ou 21, SDK Android 35.

1. Ouvrir le dossier `MP3Player_Android_Project` dans Android Studio.
2. Laisser Gradle synchroniser les dépendances.
3. Connecter un téléphone Android ou choisir un émulateur.
4. Pour créer un APK : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug sera normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

En ligne de commande, depuis la racine du projet :
`gradle assembleDebug`

## Autorisations

- Android 13+ : `READ_MEDIA_AUDIO`
- Android 12 et inférieur : `READ_EXTERNAL_STORAGE` (jusqu'à API 32)

L'application ne demande pas l'accès à tous les fichiers : elle utilise l'autorisation audio dédiée et MediaStore.

## Limites de cette première version

- Prototype de lecteur local, sans streaming ni téléchargement.
- Interface volontairement simple pour valider d'abord la permission, la détection et la lecture.
- Le service Media3 permet la lecture en arrière-plan ; les contrôles de notification et l'interface avancée seront à compléter dans une version suivante.
- Un APK signé pour distribution nécessite une clé de signature que tu dois contrôler et conserver.
